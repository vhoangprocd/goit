from webbot import Browser
Chromium = Browser()